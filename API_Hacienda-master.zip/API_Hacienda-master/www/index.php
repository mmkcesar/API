<?php
 //phpinfo();
 echo("Up & running");
?>
