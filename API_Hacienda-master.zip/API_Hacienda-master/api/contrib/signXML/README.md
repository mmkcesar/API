# Modulo para firmar un XML
Se enviar                               
        p12Url es un downloadcode previamente suministrado al subir el certificado en el modulo fileUploader -> subir_certif
        pinP12 es el codigo del certificado.
        inXml es el XML sin firmar en formato Base64. 
        tipodoc Tipo es el tipo de documento: 
               01 FE
               02 ND
               03 NC
               04 TE
               05 Mensaje Receptor
