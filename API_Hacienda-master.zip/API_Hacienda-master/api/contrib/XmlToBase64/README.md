# Modulo para encode en base 64 el xml

Se envia 
w = XmlToBase64
r = encode
xml = el String XML
