<?php

function allFE()
{
    modules_loader("clave");
}

function allNC()
{
}

function allND()
{
}
