<?php

$config['moduleName']['varname'] = "varValue";
