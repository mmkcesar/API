#About
This is the base module, use it in order to start you own modules.

###Steps
*Open config.ini and replace the values
*open module.php and replace MODULENAME with the name of your module

The file comes with some Doxygen ready stuff which is what we use to document here.
