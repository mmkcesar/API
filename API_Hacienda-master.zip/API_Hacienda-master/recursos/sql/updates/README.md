## Formato de nombre de archivo.
 El formato de los updates (actualizaciones) para sql es la siguiente:
 *año_mes_dia_numeroarchivo_api.sql*
 
 **Ejemplo:**
  - 2018_10_12_00_api.sql (Primer archivo creado el 12 de octubre del 2018) 
  - 2018_10_12_01_api.sql (Segundo archivo creado el 12 de ocubre del 2018)

## Uso de archivos
 Los *updates* únicamente son aplicados para quienes ya hayan montado el API y
 quieren estar actualizando sin necesidad de afectar los datos. Si usted recién
 está iniciando con el api **NO** es necesario usar los *updates*.
